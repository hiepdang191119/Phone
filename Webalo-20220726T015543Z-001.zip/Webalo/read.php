<?php
    if(isset($_GET["id"])&& !empty(trim($_GET["id"]))){
        require_once 'config.php';
        $sql ="SELECT*FROM tbnhanvien WHERE MaNV = ?";

        if($stmt = mysqli_prepare($link,$sql)){
            mysqli_stmt_bind_param($stmt,"i",$param_id);
            $param_id=trim($_GET["id"]);

            if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);
                if(mysqli_num_rows($result)==1){
                    $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
                    $name = $row["TenNV"];
                    $username = $row["UserName"];
                    $password = $row["Password"];
                    $birthday = $row["NgaySinh"];
                    $sex = $row["GioiTinh"];
                    $access = $row["QuyenTruyCap"];
                    $address = $row["DiaChi"];
                    $phone = $row["SoDT"];
                }
                else{
                    header("location:error.php");
                    exit();
                }
            }
            else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        mysqli_stmt_close($stmt);
        mysqli_close($link);
    }
    else{
        header("location:error.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <title>Document</title>
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
        .form-group{
            border-bottom: 1px solid #000;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h1>View Record</h1>
                    </div>
                    <div class="form-group">
                        <label>Name</label>
                        <p class="form-control-static"><?php echo $row["TenNV"]; ?></p>
                    </div>
                    <div class="form-group">
                        <label>UserName</label>
                        <p class="form-control-static"><?php echo $row["UserName"]; ?></p>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <p class="form-control-static"><?php echo $row["Password"]; ?></p>
                    </div>
                    <div class="form-group">
                        <label>NgaySinh</label>
                        <p class="form-control-static"><?php echo $row["NgaySinh"]; ?></p>
                    </div>
                    <div class="form-group">
                        <label>GioiTinh</label>
                        <p class="form-control-static"><?php echo $row["GioiTinh"]; ?></p>
                    </div>
                    <div class="form-group">
                        <label>QuyenTruyCap</label>
                        <p class="form-control-static"><?php echo $row["QuyenTruyCap"]; ?></p>
                    </div>
                    <div class="form-group">
                        <label>DiaChi</label>
                        <p class="form-control-static"><?php echo $row["DiaChi"]; ?></p>
                    </div>
                    <div class="form-group">
                        <label>SoDT</label>
                        <p class="form-control-static"><?php echo $row["SoDT"]; ?></p>
                    </div>
                    <p><a href="indexmn.php" class="btn btn-primary">Back</a></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>