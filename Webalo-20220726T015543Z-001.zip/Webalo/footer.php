<?php  ?>
    <div class="clear-both"></div>
    </div>
    </div>
    <div id="admin-footer">
        <div class="container">
            <div class="left-panel">
                DAT DEP ZAI
            </div>
            <div class="right-panel">
                <a target="_blank" href="" title="Facebook Andn Training"><img height="48" src="./assets/image/facebook.png" /></a>
                <a target="_blank" href="" title="Youtube Andn Training Channel"><img height="48" src="./assets/image/youtobe.png" /></a>
            </div>
            <div class="clear-both"></div>
        </div>
    </div>

<?php  ?>
</body>
</html>