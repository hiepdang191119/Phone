<?php
include 'header.php';
// if (!empty($_SESSION['current_user'])) {
    $abc=0;
    $sql1=mysqli_query($link,"SELECT * FROM chitietdonhang");
    $row1=mysqli_fetch_array($sql1);
    $sql2=mysqli_query($link,"SELECT * FROM tbdongDH");
    $row2 = mysqli_fetch_array($sql2);
    if(!empty($_GET['action']) && $_GET['action'] == 'status' && !empty($_POST)){
        $_SESSION['product_abc']= $_POST;
        if(!empty($_SESSION['product_abc'])){
            foreach ($_SESSION['product_abc'] as $field => $value){
                // var_dump($_GET["id"]);exit;
                if($value=="wait"){
                    
                    $status=mysqli_query($link,"UPDATE `donhang` SET `status` = 'ok' WHERE `donhang`.`id` = '". $_GET["id"]."';"); 
                    $sql3=mysqli_query($link,"SELECT tbdongDH.MaDongDH, tbdongDH.SoLuong, chitietdonhang.quantity ,tbdongDH.SoLuong-chitietdonhang.quantity as C FROM tbdongDH INNER JOIN chitietdonhang ON tbdongDH.MaDongDH=chitietdonhang.product_id WHERE chitietdonhang.order_id ='". $_GET["id"]."';");
                    $row3 = mysqli_fetch_array($sql3);
                    $sql4=mysqli_query($link,"UPDATE `tbdongDH` SET `SoLuong` = '".$row3['C']."' WHERE `tbdongDH`.`MaDongDH` = '". $row3['MaDongDH']."';");     
                    // var_dump($row3);exit;
                    while ($row3 = mysqli_fetch_array($sql3)){
                        // var_dump($row3);exit;
                        $sql4=mysqli_query($link,"UPDATE `tbdongDH` SET `SoLuong` = '".$row3['C']."' WHERE `tbdongDH`.`MaDongDH` = '". $row3['MaDongDH']."';");          
                    }

                }elseif($value=="ok"){
                    $status=mysqli_query($link,"UPDATE `donhang` SET `status` = 'wait' WHERE `donhang`.`id` = '". $_GET["id"]."';"); 
                    $sql3=mysqli_query($link,"SELECT tbdongDH.MaDongDH, tbdongDH.SoLuong, chitietdonhang.quantity ,tbdongDH.SoLuong+chitietdonhang.quantity as C FROM tbdongDH INNER JOIN chitietdonhang ON tbdongDH.MaDongDH=chitietdonhang.product_id WHERE chitietdonhang.order_id ='". $_GET["id"]."';");
                    $row3 = mysqli_fetch_array($sql3);
                    $sql4=mysqli_query($link,"UPDATE `tbdongDH` SET `SoLuong` = '".$row3['C']."' WHERE `tbdongDH`.`MaDongDH` = '". $row3['MaDongDH']."';");     
                    // var_dump($row3);exit;
                    while ($row3 = mysqli_fetch_array($sql3)){
                        // var_dump($row3);exit;
                        $sql4=mysqli_query($link,"UPDATE `tbdongDH` SET `SoLuong` = '".$row3['C']."' WHERE `tbdongDH`.`MaDongDH` = '". $row3['MaDongDH']."';");          
                    }
                }
                // var_dump($row3);exit;
                
            }
        }
        
    }
    
    if(!empty($_GET['action']) && $_GET['action'] == 'search' && !empty($_POST)){
        // var_dump($_POST);exit;
        $_SESSION['product_filter']= $_POST;
        
    }
    if(!empty($_SESSION['product_filter'])){
        // var_dump($_SESSION['product_filter']);exit;
        $where = "";
        foreach ($_SESSION['product_filter'] as $field => $value) {
            
            if(!empty($value)){
                switch ($field) {
                    case 'name':
                    $where .= (!empty($where))? " AND "."`".$field."` LIKE '%".$value."%'" : "`".$field."` LIKE '%".$value."%'";
                    break;
                    default:
                    $where .= (!empty($where))? " AND "."`".$field."` = ".$value."": "`".$field."` = ".$value."";
                    break;
                    
                }
                
            }
            
        }
        // var_dump($where);exit;
        extract($_SESSION['product_filter']);
        // var_dump($name);exit;
    }
    
    $item_per_page = (!empty($_GET['per_page'])) ? $_GET['per_page'] : 5;
    $current_page = (!empty($_GET['page'])) ? $_GET['page'] : 1;
    $offset = ($current_page - 1) * $item_per_page;
    if(!empty($where)){
        $totalRecords = mysqli_query($link, "SELECT * FROM donhang where (".$where.")");
    }else{
        $totalRecords = mysqli_query($link, "SELECT * FROM donhang");
    }
    
    
        $totalRecords = $totalRecords->num_rows;
    
    // var_dump($totalRecords);exit;
    $totalPages = ceil($totalRecords / $item_per_page);
    if(!empty($where)){
        $products = mysqli_query($link, "SELECT * FROM donhang where (".$where.") ORDER BY id DESC LIMIT " . $item_per_page . " OFFSET " . $offset);
        // var_dump($products);exit;
    }else{
        $products = mysqli_query($link, "SELECT * FROM donhang ORDER BY id DESC LIMIT " . $item_per_page . " OFFSET " . $offset);
    }
    // $products = mysqli_query($link, "SELECT * FROM donhang ORDER BY id DESC LIMIT " . $item_per_page . " OFFSET " . $offset);
    
    mysqli_close($link);
    ?>
    <div class="main-content">
        <h1>Danh sách đơn hàng</h1>
        <div class="product-items">
            <div class="buttons">
                <a href="create4.php">Thêm đơn hàng</a>
            </div>
            
            <div class="product-search">
                    <form action="indexmn4.php?action=search" method="POST">
                        <fieldset>
                            <legend>Tìm kiếm đơn hàng:</legend>
                            ID: <input type="text" name="id" value="<?=!empty($id)?$id:""?>"/>
                            Tên đơn hàng: <input type="text" name="name" value="<?=!empty($name)?$name:""?>"/>
                            <input type="submit" value="Tìm"/>
                        </fieldset>
                    </form>
            </div>
            <div class="total-items">
                <span>Có tất cả <strong><?=$totalRecords?></strong> đơn hàng trên <strong><?=$totalPages?></strong> trang</span>
            </div>
            <ul>
                <li class="product-item-heading">
                    <div class="product-prop product-id">ID</div>
                    <div class="product-prop product-name" style="width: 70px">Name</div>
                    <div class="product-prop product-id" style="width: 70px">phone</div>
                    <div class="product-prop product-price">address</div>
                    <div class="product-prop product-name" style="width: 81px">total</div>
                    <div class="product-prop product-name" style="width: 100px">status</div>
                    
                    <div class="product-prop product-time" style="width: 120px">Ngày tạo</div>
                    <div class="product-prop product-time" style="width: 120px">Ngày cập nhật</div>
                    <div class="product-prop product-button">
                        Xóa
                    </div>
                    <div class="product-prop product-button">
                        Sửa
                    </div>
                    <div class="product-prop product-button">
                        Xem
                    </div>
                    
                    <div class="clear-both"></div>
                </li>
                <?php
               
                while ($row = mysqli_fetch_array($products)) {
                    ?>
                    <li>
                        <div class="product-prop product-id"><?= $row['id'] ?></div>
                        <div class="product-prop product-name" style="width: 70px"><?= $row['name'] ?></div>
                        <div class="product-prop product-id" style="width: 70px"><?= $row['phone'] ?></div>
                        <div class="product-prop product-price"><?= $row['address'] ?></div>
                        <div class="product-prop product-name" style="width: 81px"><?=number_format($row['total'],0,",",".")?></div>                    
                        <div class="product-prop product-name" style="width: 100px">
                            
                            <form action="indexmn4.php?action=status&id=<?= $row['id'] ?>" method="POST">
                                <fieldset style="height: 73px;border: none;">
                                <input type="submit" name="status" id="<?= $row['status'] ?>" value="<?= $row['status'] ?>">
                                </fieldset>
                            </form>
                            
                        </div>
                        
                        <div class="product-prop product-time" style="width: 120px"><?= date('d/m/Y', $row['created_time']) ?></div>
                        <div class="product-prop product-time" style="width: 120px"><?= date('d/m/Y H:i', $row['last_updated']) ?></div>
                        <div class="product-prop product-button">
                            <a href="delete4.php?id=<?= $row['id'] ?>">Xóa</a>
                        </div>
                        <div class="product-prop product-button">
                            <a href="update4.php?id=<?= $row['id'] ?>">Sửa</a>
                        </div>
                        <div class="product-prop product-button">
                            <a href="read4.php?id=<?= $row['id'] ?>">Xem</a>
                        </div>
                        
                        <div class="clear-both"></div>
                    </li>
                <?php } ?>
            </ul>
            <?php
            include './pagination.php';
            ?>
            <div class="clear-both"></div>
        </div>
    </div>
    <?php
// }
include './footer.php';
?>