<?php
    require_once 'config.php';
    $id=$name=$username=$password=$birthday=$sex=$access=$address=$phone="";
    $id_err=$name_err=$username_err=$password_err=$birthday_err=$sex_err=$access_err=$address_err=$phone_err="";
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $input_id=trim($_POST["id"]);
        if(empty($input_id)){
            $id_err='Please enter an id';
        }else{
            $id=$input_id;
        }
        $input_name = trim($_POST["name"]);
        if(empty($input_name)){
            $name_err="Please enter a name.";
        } elseif(!filter_var(trim($_POST["name"]),FILTER_VALIDATE_REGEXP,
            array("options"=>array("regexp"=>"/^[a-zA-Z'-.\s ]+$/")))){
                $name_err='Please enter a valid name.';
            }else{
                $name=$input_name;
            }
        $input_username=trim($_POST["username"]);
        if(empty($input_username)){
            $username_err='Please enter an username';
        }else{
            $username=$input_username;
        }
        $input_password=trim($_POST["password"]);
        if(empty($input_password)){
            $password_err='Please enter an password';
        }else{
            $password=$input_password;
        }
        $input_birthday=trim($_POST["birthday"]);
        if(empty($input_birthday)){
            $birthday_err='Please enter an birthday';
        }else{
            $birthday=$input_birthday;
        }
        $input_sex=trim($_POST["sex"]);
        if(empty($input_sex)){
            $sex_err='Please enter an sex';
        }else{
            $sex=$input_sex;
        }
        $input_access=trim($_POST["access"]);
        if(empty($input_access)){
            $access_err='Please enter an access';
        }else{
            $access=$input_access;
        }
        $input_address=trim($_POST["address"]);
        if(empty($input_address)){
            $address_err='Please enter an address';
        }else{
            $address=$input_address;
        }
        $input_phone=trim($_POST["phone"]);
        if(empty($input_phone)){
            $phone_err='Please enter an phone';
        }elseif(!filter_var(trim($_POST["phone"]),FILTER_VALIDATE_REGEXP,
        array("options"=>array("regexp"=>"/^[0-9]+$/")))){
            $phone_err='Please enter a valid phone.';
        }else{
            $phone=$input_phone;
        }

        if(empty($name_err) && empty($username_err) && empty($password_err) && empty($birthday_err) && empty($sex_err) && empty($access_err) && empty($address_err) && empty($phone_err)){
            $sql="INSERT INTO tbnhanvien (MaNV,TenNV,UserName,Password,NgaySinh,GioiTinh,QuyenTruyCap,DiaChi,SoDT) VALUES(?,?,?,?,?,?,?,?,?)";
            if($stmt=mysqli_prepare($link,$sql)){
                mysqli_stmt_bind_param($stmt,"ssssssssd",$param_id,$param_name,$param_username,$param_password,$param_birthday,$param_sex,$param_access,$param_address,$param_phone);
                $param_id=$id;
                $param_name=$name;
                $param_username=$username;
                $param_password=$password;
                $param_birthday=$birthday;
                $param_sex=$sex;
                $param_access=$access;
                $param_address=$address;
                $param_phone=$phone;
                if(mysqli_stmt_execute($stmt)){
                    header("location: indexmn.php");
                    exit();
                }else{
                    echo "Something went wrong. Please try agian later.";
                }
            }
            mysqli_stmt_close($stmt);
        }
        mysqli_close($link);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <title>Document</title>
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Create Record</h2>
                    </div>
                    <p>Please fill this form and submit to add tbnhanvien record to the database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo(!empty($id_err)) ? 'has-error' : ''; ?>">
                            <label>MaNV</label>
                            <input type="text" name="id" class="form-control" value="">
                            <span class="help-block"><?php echo $id_err ;?></span>
                        </div>    
                        <div class="form-group <?php echo(!empty($name_err)) ? 'has-error' : ''; ?>">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control" value="">
                            <span class="help-block"><?php echo $name_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($username_err)) ? 'has-error' : ''; ?>">
                            <label>UserName</label>
                            <input type="text" name="username" class="form-control" value="">
                            <span class="help-block"><?php echo $username_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($password_err)) ? 'has-error' : ''; ?>">
                            <label>Password</label>
                            <input type="text" name="password" class="form-control" value="">
                            <span class="help-block"><?php echo $password_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($birthday_err)) ? 'has-error' : ''; ?>">
                            <label>Birthday</label>
                            <input type="text" name="birthday" class="form-control" value="">
                            <span class="help-block"><?php echo $birthday_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($access_err)) ? 'has-error' : ''; ?>">
                            <label>Access</label>
                            <input type="text" name="access" class="form-control" value="">
                            <span class="help-block"><?php echo $access_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($address_err)) ? 'has-error' : ''; ?>">
                            <label>Address</label>
                            <input type="text" name="address" class="form-control" value="">
                            <span class="help-block"><?php echo $address_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($sex_err)) ? 'has-error' : ''; ?>">
                            <label>Sex</label>
                            <input type="text" name="sex" class="form-control" value="">
                            <span class="help-block"><?php echo $sex_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($phone_err)) ? 'has-error' : ''; ?>">
                            <label>Phone</label>
                            <input type="number" name="phone" class="form-control" value="">
                            <span class="help-block"><?php echo $phone_err ;?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="indexmn.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>