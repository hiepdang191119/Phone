<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register-XYZ</title>
    <link rel="stylesheet" href="./assets/css/register.css">
</head>
<body>
    
<?php
     require_once 'config.php';
     $name=$username=$password=$repassword=$email=$address=$phone="";
    if(isset($_POST['submit'])){
        $name=$_POST["name"];
        $username=$_POST["username"];
        $password=$_POST["password"];
        $repassword=$_POST["repassword"];
        $email=$_POST["email"];
        $address=$_POST["address"];
        $phone=$_POST["phone"];
        // $input_name = trim($_POST["name"]);
        // if(empty($input_name)){
        //     $error="Please enter a name.";
        //     echo "<script type='text/javascript'>alert('$error');</script>";
           
        // } elseif(!filter_var(trim($_POST["name"]),FILTER_VALIDATE_REGEXP,
        //     array("options"=>array("regexp"=>"/^[a-zA-Z'-.\s ]+$/")))){
        //         $error="Please enter a valid name.";
                
        //     }else{
        //         $name=$input_name;
        //     }
        // $input_username=trim($_POST["username"]);
        // if(empty($input_username)){
        //     $error="Please enter an username";
        // }else{
        //     $username=$input_username;
        // }
        // $input_password=trim($_POST["password"]);
        // if(empty($input_password)){
        //     $error='Please enter an password';
        // }else{
        //     $password=$input_password;
        // }
        // $input_repassword=trim($_POST["repassword"]);
        // if(empty($input_repassword)){
        //     $error='Please enter an repassword';
        // }else{
        //     $repassword=$input_repassword;
        // }       
        // $input_email=trim($_POST["email"]);
        // if(empty($input_email)){
        //     $error='Please enter an email';
        // }else{
        //     $email=$input_email;
        // }
        // $input_address=trim($_POST["address"]);
        // if(empty($input_address)){
        //     $error='Please enter an address';
        // }else{
        //     $address=$input_address;
        // }
        // $input_phone=trim($_POST["phone"]);
        // if(empty($input_phone)){
        //     $error='Please enter an phone';
        // }elseif(!filter_var(trim($_POST["phone"]),FILTER_VALIDATE_REGEXP,
        // array("options"=>array("regexp"=>"/^[0-9]+$/")))){
        //     $error='Please enter a valid phone.';
        // }else{
        //     $phone=$input_phone;
        // }
        // if($password != $repassword){
        //     $error= "ko trùng pass";
            
        // }
        if(empty($_POST['name'])){
            $error="Bạn chưa nhập tên";
        } elseif(!filter_var(trim($_POST["name"]),FILTER_VALIDATE_REGEXP,
        array("options"=>array("regexp"=>"/^[a-zA-Z'-.\s ]+$/")))){
            $error='Please enter a valid name.';
        }elseif(empty($_POST['username'])){
            $error="Bạn chưa nhập username";
        }elseif(empty($_POST['password'])){
            $error="Bạn chưa nhập password";
        }elseif(empty($_POST['repassword'])){
            $error="Bạn chưa nhập repassword";
        }elseif(empty($_POST['email'])){
            $error="Bạn chưa nhập email";
        }elseif(empty($_POST['address'])){
            $error="Bạn chưa nhập địa chỉ";
        }elseif(empty($_POST['phone'])){
            $error="Bạn chưa nhập điện thoại";
        }elseif(!filter_var(trim($_POST["phone"]),FILTER_VALIDATE_REGEXP,
        array("options"=>array("regexp"=>"/^[0-9]+$/")))){
            $error='Please enter a valid phone.';
        }
        elseif(
            $sql="SELECT * FROM tbkhachhang WHERE UserName='$username' "){
                $abc = mysqli_query($link,$sql);
            if(mysqli_num_rows($abc)>0){
                $error= "có ten trùng";
            }else{ $sql="INSERT INTO tbkhachhang (TenKH,UserName,Password,Email,DiaChi,SoDT) VALUES ('$name','$username','$password','$email','$address','$phone')";
                mysqli_query($link,$sql);
                echo "<script type='text/javascript'>alert('đăng kí thành công');</script>";
                header('Location: ./login.php');
            }
            
        }
        if(!empty($error)){
            echo "<script type='text/javascript'>alert('$error');</script>";}
        
    }
?>
    <form action="register.php" method="POST">
        <div class="register">
                <h2>Register</h2>
                <div class="register-enter">
                    <p>Họ và Tên :</p>
                    <input type="text" name="name" placeholder="Name ..."  >
                </div>
                <div class="register-enter">
                    <p>Tên đăng nhập :</p>
                    <input type="text"  name="username" placeholder="Username ...">
                </div>
                <div class="register-enter">
                    <p>Mật khẩu :</p>
                    <input type="password"  name="password" placeholder="Password ...">
                </div>
                <div class="register-enter">
                    <p>Nhập lại mật khẩu :</p>
                    <input type="password"  name="repassword" placeholder="Password ...">
                </div>
                <div class="register-enter">
                    <p>Gmail :</p>
                    <input type="email"  name="email" placeholder="Gmail ...">
                </div>
                <div class="register-enter">
                    <p>Địa chỉ :</p>
                    <input type="text"  name="address" placeholder="Address ...">
                </div>
                <div class="register-enter">
                    <p>Số điện thoại :</p>
                    <input type="number"  name="phone" placeholder="Phone ...">
                </div>
                <button class="btn-register" type="submit" name="submit">Register</button>
        </div>
    </form>
</body>
</html>