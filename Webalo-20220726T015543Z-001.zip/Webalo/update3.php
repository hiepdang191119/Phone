<?php
    require_once 'config.php';
    $name=$idhangsx=$image=$price=$specifications=$quantity="";
    $name_err=$idhangsx_err=$image_err=$price_err=$specifications_err=$quantity_err="";
    if(isset($_POST["id"])&& !empty($_POST["id"])){
        $id=$_POST["id"];
        $input_name=trim($_POST["name"]);
        if(empty($input_name)){
            $name_err="Please enter a name";
        }elseif(!filter_var(trim($_POST["name"]),FILTER_VALIDATE_REGEXP,
        array("options"=>array("regexp"=>"/^[a-zA-Z'-.\s ]+$/")))){
            $name_err='Please enter a valid name.';
        }else{
            $name=$input_name;
        }
        $input_idhangsx=trim($_POST["idhangsx"]);
        if(empty($input_idhangsx)){
            $idhangsx_err='Please enter an idhangsx';
        }else{
            $idhangsx=$input_idhangsx;
        }
        $input_image=trim($_POST["image"]);
        if(empty($input_image)){
            $image_err='Please enter an image';
        }else{
            $image=$input_image;
        }
        $input_price=trim($_POST["price"]);
        if(empty($input_price)){
            $price_err='Please enter an price';
        }else{
            $price=$input_price;
        }
        $input_specifications=trim($_POST["specifications"]);
        if(empty($input_specifications)){
            $specifications_err='Please enter an specifications';
        }else{
            $specifications=$input_specifications;
        }
        $input_quantity=trim($_POST["quantity"]);
        if(empty($input_quantity)){
            $quantity_err='Please enter an quantity';
        }else{
            $quantity=$input_quantity;
        }
       

        if(empty($name_err) && empty($idhangsx_err) && empty($image_err) && empty($price_err) && empty($specifications_err) && empty($quantity_err)){
            $sql="UPDATE tbdongDH SET TenDongDH=?,MaHangSx=?,HinhAnh=?,DonGia=?,ThongSo=?,SoLuong=? WHERE MaDongDH=?";
            if($stmt=mysqli_prepare($link,$sql)){
                mysqli_stmt_bind_param($stmt,"ssssssi",$param_name,$param_idhangsx,$param_image,$param_brithday,$param_specifications,$param_quantity,$param_id);
                $param_name=$name;
                $param_idhangsx=$idhangsx;
                $param_image=$image;
                $param_brithday=$price;
                $param_specifications=$specifications;
                $param_quantity=$quantity;
                
                $param_id=$id;
                if(mysqli_stmt_execute($stmt)){
                    header("location: product_listing.php");
                    exit();
                }else{
                    echo "Something went wrong. Please try agian later.";
                }
            }
            mysqli_stmt_close($stmt);
        }
        mysqli_close($link);
    }else{
        if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
            $id=trim($_GET["id"]);
            $sql="SELECT * FROM tbdongDH WHERE MaDongDH =?";
            if($stmt =mysqli_prepare($link,$sql)){
                mysqli_stmt_bind_param($stmt,"i",$param_id);
                $param_id=$id;
                if(mysqli_stmt_execute($stmt)){
                    $result = mysqli_stmt_get_result($stmt);
                    if(mysqli_num_rows($result)==1){
                        $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
                        $name = $row["TenDongDH"];
                        $idhangsx = $row["MaHangSx"];
                        $image = $row["HinhAnh"];
                        $price = $row["DonGia"];
                        $specifications = $row["ThongSo"];
                        $quantity = $row["SoLuong"];
                       
                    }
                    else
                    {
                        header("location:error.php");
                        exit();
                    }
                }else{
                    echo "Oops! Something went wrong. Please try again later.";
                }
            }
            mysqli_stmt_close($stmt);
            mysqli_close($link);
        }
        else{
            header("location:error.php");
            exit();
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <title>Document</title>
    <style>
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Update Record</h2>          
                    </div>
                    <p>Please edit the input values and to update the record.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group <?php echo(!empty($name_err)) ? 'has-error' : ''; ?>">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo $name; ?>">
                            <span class="help-block"><?php echo $name_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($idhangsx_err)) ? 'has-error' : ''; ?>">
                            <label>idhangsx</label>
                            <input type="text" name="idhangsx" class="form-control" value="<?php echo $idhangsx; ?>">
                            <span class="help-block"><?php echo $idhangsx_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($image_err)) ? 'has-error' : ''; ?>">
                            <label>image</label>
                            <input type="text" name="image" class="form-control" value="<?php echo $image; ?>">
                            <span class="help-block"><?php echo $image_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($price_err)) ? 'has-error' : ''; ?>">
                            <label>Price</label>
                            <input type="number" name="price" class="form-control" value="<?php echo $price; ?>">
                            <span class="help-block"><?php echo $price_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($specifications_err)) ? 'has-error' : ''; ?>">
                            <label>specifications</label>
                            <input type="text" name="specifications" class="form-control" value="<?php echo $specifications; ?>">
                            <span class="help-block"><?php echo $specifications_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($quantity_err)) ? 'has-error' : ''; ?>">
                            <label>quantity</label>
                            <input type="number" name="quantity" class="form-control" value="<?php echo $quantity; ?>">
                            <span class="help-block"><?php echo $quantity_err ;?></span>
                        </div>
                        
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="product_listing.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>