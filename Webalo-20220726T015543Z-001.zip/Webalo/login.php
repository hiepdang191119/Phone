<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login-XYZ</title>
    <link rel="stylesheet" href="./assets/css/login.css">
</head>
<style>
    a{
        text-decoration: none;
        color: #000;
    }
</style>
<body>
<?php
    require_once 'config.php';
    if(isset($_POST["submit"]) && $_POST["username"]!='' && $_POST["password"]!=''){
        $username=$_POST["username"];
        $password=$_POST["password"];
        $sql="SELECT *FROM tbkhachhang WHERE UserName='$username' AND Password='$password'";
        $result=mysqli_query($link,$sql);
        if(mysqli_num_rows($result)>0){
             header("location: index.php");
        }else{
            
                $sql="SELECT *FROM tbnhanvien WHERE UserName='$username' AND Password='$password' AND QuyenTruyCap='admin'";
                $result=mysqli_query($link,$sql);
                if(mysqli_num_rows($result)>0){
                     header("location: product_listing.php");
                }else{
                    echo "<script type='text/javascript'>alert('đăng nhập không thành công');</script>";
                }
            
        }
        if ($result->num_rows > 0) {
            $user = mysqli_fetch_assoc($result);
            if (session_status() == PHP_SESSION_NONE) {
                session_start();
            }
            $_SESSION['current_user'] = $user;
            
        }
    }
?>
    <form action="login.php" method="POST">
        <div class="login">
            <h2>Login</h2>
            <div class="enter">
                <img src="./assets/img/login/icon-user.png" alt="">
                <input type="text" placeholder="username" name="username">
            </div>
            <div class="enter">
                <img src="./assets/img/login/icon-password.png" alt="">
                <input type="password" placeholder="userpassword" name="password">
            </div>
            <div class="login-btn">
                <button class="btn-login" type="submit" name="submit">Login</button>
                <!-- <a href="register.php"><button class="btn-login">Register</button></a> -->
                <button class="btn-login"><a href="register.php">Register</a></button>
            </div>
        </div>
    </form>
</body>
</html>