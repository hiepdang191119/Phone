<?php
include 'header.php';
// if (!empty($_SESSION['current_user'])) {
    
    if(!empty($_GET['action']) && $_GET['action'] == 'search' && !empty($_POST)){
        // var_dump($_POST);exit;
        $_SESSION['product_filter']= $_POST;
        
    }
    if(!empty($_SESSION['product_filter'])){
        // var_dump($_SESSION['product_filter']);exit;
        $where = "";
        foreach ($_SESSION['product_filter'] as $field => $value) {
            
            if(!empty($value)){
                switch ($field) {
                    case 'TenDongDH':
                    $where .= (!empty($where))? " AND "."`".$field."` LIKE '%".$value."%'" : "`".$field."` LIKE '%".$value."%'";
                    break;
                    default:
                    $where .= (!empty($where))? " AND "."`".$field."` = ".$value."": "`".$field."` = ".$value."";
                    break;
                }
            }
            // var_dump($where);exit;
        }
        // var_dump($where);exit;
        extract($_SESSION['product_filter']);
        // var_dump($TenDongDH);exit;
    }
    $item_per_page = (!empty($_GET['per_page'])) ? $_GET['per_page'] : 5;
    $current_page = (!empty($_GET['page'])) ? $_GET['page'] : 1;
    $offset = ($current_page - 1) * $item_per_page;
    if(!empty($where)){
        $totalRecords = mysqli_query($link, "SELECT * FROM tbdongDH where (".$where.")");
    }else{
        $totalRecords = mysqli_query($link, "SELECT * FROM tbdongDH");
    }
    $totalRecords = $totalRecords->num_rows;
    $totalPages = ceil($totalRecords / $item_per_page);
    if(!empty($where)){
        $products = mysqli_query($link, "SELECT * FROM tbdongDH where (".$where.") ORDER BY MaDongDH DESC LIMIT " . $item_per_page . " OFFSET " . $offset);
        // var_dump($products);exit;
    }else{
        $products = mysqli_query($link, "SELECT * FROM tbdongDH ORDER BY MaDongDH DESC LIMIT " . $item_per_page . " OFFSET " . $offset);
    }
    // $products = mysqli_query($link, "SELECT * FROM tbdongDH ORDER BY MaDongDH DESC LIMIT " . $item_per_page . " OFFSET " . $offset);

    mysqli_close($link);
    ?>
    <div class="main-content">
        <h1>Danh sách sản phẩm</h1>
        <div class="product-items">
            <div class="buttons">
                <a href="create3.php">Thêm sản phẩm</a>
            </div>
            
            <div class="product-search">
                    <form action="product_listing.php?action=search" method="POST">
                        <fieldset>
                            <legend>Tìm kiếm sản phẩm:</legend>
                            ID: <input type="text" name="MaDongDH" value="<?=!empty($MaDongDH)?$MaDongDH:""?>"/>
                            Tên sản phẩm: <input type="text" name="TenDongDH" value="<?=!empty($TenDongDH)?$TenDongDH:""?>"/>
                            <input type="submit" value="Tìm"/>
                        </fieldset>
                    </form>
            </div>
            <div class="total-items">
                <span>Có tất cả <strong><?=$totalRecords?></strong> sản phẩm trên <strong><?=$totalPages?></strong> trang</span>
            </div>
            <ul>
                <li class="product-item-heading">
                    <div class="product-prop product-id">ID</div>
                    <div class="product-prop product-id" style="width: 70px">MaHangSX</div>
                    <div class="product-prop product-img">Ảnh</div>
                    <div class="product-prop product-name">Tên sản phẩm</div>
                    <div class="product-prop product-price">Đơn Giá</div>
                    <div class="product-prop product-name">Thông Số</div>
                    <div class="product-prop product-id" style="width: 62px">Số Lượng</div>
                    <div class="product-prop product-button">
                        Xóa
                    </div>
                    <div class="product-prop product-button">
                        Sửa
                    </div>
                    <div class="product-prop product-button">
                        Xem
                    </div>
                    
                    <div class="clear-both"></div>
                </li>
                <?php
                while ($row = mysqli_fetch_array($products)) {
                    ?>
                    <li>
                        <div class="product-prop product-id"><?= $row['MaDongDH'] ?></div>
                        <div class="product-prop product-id" style="width: 70px"><?= $row['MaHangSx'] ?></div>
                        <div class="product-prop product-img"><img src="./assets/image/<?= $row['HinhAnh'] ?>" alt="<?= $row['TenDongDH'] ?>" title="<?= $row['TenDongDH'] ?>" /></div>
                        <div class="product-prop product-name"><?= $row['TenDongDH'] ?></div>
                        <div class="product-prop product-price"><?=number_format($row['DonGia'],0,",",".")?></div>
                        <div class="product-prop product-name">-------</div>
                        <div class="product-prop product-id" style="width: 62px"><?= $row['SoLuong'] ?></div>
                        <div class="product-prop product-button">
                            <a href="delete3.php?id=<?= $row['MaDongDH'] ?>">Xóa</a>
                        </div>
                        <div class="product-prop product-button">
                            <a href="update3.php?id=<?= $row['MaDongDH'] ?>">Sửa</a>
                        </div>
                        <div class="product-prop product-button">
                            <a href="read3.php?id=<?= $row['MaDongDH'] ?>">Xem</a>
                        </div>
                        
                        <div class="clear-both"></div>
                    </li>
                <?php } ?>
            </ul>
            <?php
            include './pagination.php';
            ?>
            <div class="clear-both"></div>
        </div>
    </div>
    <?php
// }
include './footer.php';
?>