<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Diện Thoại</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    <link rel="stylesheet" href="./assets/fonts/themify-icons-font/themify-icons-font/themify-icons/themify-icons.css">
    <link rel="stylesheet" href="./assets/css/style.css">
    <style>
        #header{
            height: auto;
            border: 1px solid #000;
        }
        .cart-img{
            width: 80px;
            height: 80px;
            border: 1px solid #000;
        }
        .tbody{
            text-align: center;
        }
        .table{
            background-color: #fff;
        }
        .product-quantity input{
            text-align: center;
        }
        .product-name{
            font-weight: 700;
        }
        .abc{
            margin-left: 40px;
            width: 200px;
            float: right;
        }
        .ab{
            width: 30%;
            margin-left: 30px;
        }
        #form-button{
            float: right;
        }
        
        

    </style>
</head>
<body>
   <div id="main">
       <div id="top">
            <div id="logo">
                <a href="index.php" class="logo-web">
                    <img src="./assets/img/top/logo.jpg" alt="Đồng hồ thời thượng" class="img-logo">   
                </a>
            </div>
            <div id="search">
                <form action="">
                    <input type="text" placeholder="Bạn cần tìm gì ?">
                    <button class="btn-search ti-search"></button>
                </form>
            </div>
            <div id="nav-top">              
                <ul>
                    <li>
                        <a href="#">
                            <i class="icon-navtop ti-agenda"></i>
                            <div>
                                <span>Tin tức</span>
                                <p>Hot news</p>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="icon-navtop ti-mobile"></i>
                            <div>
                                <span>Gọi mua hàng</span>
                                <p>19001001</p>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="icon-navtop ti-location-pin"></i>
                            <div>
                                <span>Chuỗi cửa hàng</span>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="icon-navtop ti-shopping-cart"></i>
                            <div>
                                <span>Giỏ hàng</span>                              
                            </div>
                        </a>
                    </li>
                </ul>
            </div>
            <div id="login-top">
                <a href="login.php" class="icon-login-top ti-user">
                    <div>
                        <span>Đăng nhập</span>
                    </div>
                </a>
            </div>
       </div>
       
       <div id="header">
            <?php
                
                include 'config.php';
                if(!isset($_SESSION["cart"])){
                   $_SESSION["cart"] = array();
                    
                }
                $error=false;
                $success=false;
                if(isset($_GET['action'])){
                    function update_cart($add=false){
                       
                        foreach($_POST['quantity'] as $id =>$quantity ){
                            if($quantity==0){
                                unset($_SESSION["cart"][$id]);
                            }else{
                                if($add){
                                    $_SESSION["cart"][$id]+=$quantity;
                                }else{
                                    $_SESSION["cart"][$id]=$quantity;
                                }
                            }
                            
                        } 
                    }
                    switch($_GET['action']){
                        case "add":
                            update_cart(true);
                            header('location: ./cart.php');                  
                            break;
                        case "delete":
                            if(isset($_GET['id'])){
                                unset($_SESSION["cart"][$_GET['id']]);
                            }
                            header('location: ./cart.php');
                            break;
                        case "submit":
                            if(isset($_POST['update_click'])){
                               update_cart();
                               header('location: ./cart.php');       
                            }elseif($_POST['order_click']){
                                if (!empty($_SESSION['current_user'])) {
                                    if(empty($_POST['name'])){
                                        $error="Bạn chưa nhập tên";
                                    } elseif(!filter_var(trim($_POST["name"]),FILTER_VALIDATE_REGEXP,
                                    array("options"=>array("regexp"=>"/^[a-zA-Z'-.\s ]+$/")))){
                                        $error='Please enter a valid name.';
                                    }elseif(empty($_POST['phone'])){
                                        $error="Bạn chưa nhập điện thoại";
                                    }elseif(!filter_var(trim($_POST["phone"]),FILTER_VALIDATE_REGEXP,
                                    array("options"=>array("regexp"=>"/^[0-9]+$/")))){
                                        $error='Please enter a valid phone.';
                                    }elseif(empty($_POST['address'])){
                                        $error="Bạn chưa nhập địa chỉ";
                                    }elseif(empty($_POST['quantity'])){
                                        $error="Giỏ hàng rỗng";
                                    }
                                    if($error==false && !empty($_POST['quantity'])){
                                        
                                        $products=mysqli_query($link,"SELECT*FROM tbdongDH WHERE MaDongDH IN (".implode(",",array_keys($_POST['quantity'])).")");
                                        $total=0;
                                        $orderProducts=array();
                                        while($row=mysqli_fetch_array($products)){
                                            $orderProducts[]=$row;
                                            $total+=$row['DonGia']*$_POST['quantity'][$row['MaDongDH']];
                                        }
                                        
                                        $insertOrder=mysqli_query($link,"INSERT INTO `donhang` (`id`, `name`, `phone`, `address`, `note`,`status` ,`total`, `created_time`, `last_updated`) VALUES (NULL, '".$_POST['name']."', '".$_POST['phone']."', '".$_POST['address']."', '".$_POST['note']."','wait', '".$total."', '".time()."', '".time()."');");
                                        $orderID=$link->insert_id;
                                        $insertString="";
                                        
                                        foreach($orderProducts as $key =>$product){
                                        
                                            $insertString .="(NULL,'".$orderID."','".$product['MaDongDH']."','".$_POST['quantity'][$product['MaDongDH']]."','".$product['DonGia']."','".time()."','".time()."')";
                                            if($key!=count($orderProducts)-1){
                                                $insertString .=",";
                                            }
                                        }
                                        
                                        $insertOrder=mysqli_query($link,"INSERT INTO `chitietdonhang` (`id`, `order_id`, `product_id`, `quantity`, `price`, `created_time`, `last_updated`) VALUES ".$insertString.";");
                                        $success="Đặt hàng hành công";
                                        unset($_SESSION["cart"]);
                                    }
                                }else{
                                    header('Location: ./login.php');
                                }
                                
                            }
                            
                            break;
                    }              
                }
                if(!empty($_SESSION["cart"])){
                   
                    $products=mysqli_query($link,"SELECT *FROM tbdongDH WHERE MaDongDH IN (".implode(",",array_keys($_SESSION["cart"])).")");
                    // $products=mysqli_query($link,"SELECT *FROM tbdongDH WHERE MaDongDH IN (2,3,5)");
                     
                 }
                // $result=mysqli_query($link,"SELECT *FROM tbdongDH WHERE MaDongDH= ".$_GET['id']);
                // $product=mysqli_fetch_assoc($result);
                if(!empty($error)){
                    echo "<script type='text/javascript'>alert('$error');</script>";
                }elseif(!empty($success)){
                    echo "<script type='text/javascript'>alert('$success');</script>";
                }
                
            ?>
            <div class="content">
                <div class="title">
                    <p><b><i>Giỏ hàng</i></b></p>
                </div>
               
                
                   
                    <form id="cart-form" action="cart.php?action=submit" method="POST">
                        <table class='table table-bordered table-striped'>
                            <thead>
                                <tr>
                                    <th class="product-number">STT</th>
                                    <th class="product-name">Tên sản phẩm</th>
                                    <th class="product-img">Ảnh sản phẩm</th>
                                    <th class="product-price">Đơn Giá</th>
                                    <th class="product-quantity">Số lượng</th>
                                    <th class="product-money">Thành tiền</th>
                                    <th class="product-delete">Xóa</th>
                                </tr>
                            </thead>
                            <tbody class="tbody">
                                
                                <?php 
                                if(!empty($products)){
                                    $total=0;
                                    $num=1;
                                    while($row=mysqli_fetch_array($products)) {?>
                                    
                                    <tr>
                                        <td class="product-number"><?=$num++;?></td>
                                        <td class="product-name"><?=$row['TenDongDH']?></td>
                                        <td class="product-img"><img src="./assets/image/<?=$row['HinhAnh']?>" class="cart-img" alt=""></td>
                                        <td class="product-price"><?=number_format($row['DonGia'],0,",",".")?></td>
                                        <td class="product-quantity"><input size="1" type="text" value="<?=$_SESSION["cart"][$row['MaDongDH']]?>" name="quantity[<?=$row['MaDongDH']?>]"/></td>
                                        <td class="product-money"><?=number_format($row['DonGia']*$_SESSION["cart"][$row['MaDongDH']],0,",",".")?></td>
                                        <td class="product-delete"><a href="cart.php?action=delete&id=<?=$row['MaDongDH']?>">Xóa</a></td>
                                    </tr>
                                    <?php 
                                    $total+=$row['DonGia']*$_SESSION["cart"][$row['MaDongDH']]; 
                                    $num++;
                                    }
                                    ?>
                                        <tr>
                                            <td class="product-number">---</td>
                                            <td class="product-name">Tổng tiền</td>
                                            <td class="product-img">---</td>
                                            <td class="product-price">--- </td>
                                            <td class="product-quantity">---</td>
                                            <td class="product-money"><?=number_format($total,0,",",".")?></td>
                                            <td class="product-delete">---</td>
                                        </tr>
                                    <?php
                                    
                                }
                               
                                
                                ?>
                                        
                                
                                
                                
                            </tbody>
                            
                        </table>
                        <div id="form-button">
                            <input type="submit" name="update_click" value="Cập nhật"/>
                        </div>
                        <div class="ab">
                            <div><label>Người nhận:</label><input class="abc" type="text" value="" name="name"/></div>
                            <div><label>Điện thoại:</label><input class="abc" type="text" value="" name="phone"/></div>
                            <div><label>Địa chỉ:</label><input class="abc" type="text" value="" name="address"/></div>
                            <div><label>Ghi chú:</label><textarea class="abc" name="note" id="" cols="30" rows="?"></textarea></div>
                        </div>
                        <input type="submit" name="order_click" value="Đặt hàng">
                    </form>
                
                
            </div>
       </div>

       
       <div id="footer">
           <div class="cty">
            <p><b><i>Công ty cổ phần XYZ</i></b></p>
           </div>
           <div class="intro footercss">
                <p><b>Thông tin công ty</b></p>
                <div>
                    <p>Công ty cổ phần XYZ</p>
                    <p>Địa chỉ : Số 21 đường A Hà Nội</p>
                    <p>Ngày thành lập : 21/10/2021</p>
                </div>
           </div>
           <div class="advise footercss">
                <p><b>Hỗ trợ khách hàng</b></p>
                <div>
                    <p>Gọi mua hàng: <b style="color: blue;">085 5100 001</b></p>
                    <p>Hỗ trợ kĩ thuật: <b style="color: blue;">1800 6502</b></p>
                    <p>Gọi hợp tác kinh doanh:<b style="color: blue;"> 1900 6122</b></p>
                </div>
           </div>
           <div class="info footercss">
                <p><b>Thông tin liên hệ</b></p>
                <div class="info-nav">
                    <ul>
                        <li><a href="#"><i class="ti-facebook"></i>facebook/xyz</a></li>
                        <li><a href="#"><i class="ti-youtube"></i>youtube/xyz</a></li>
                        <li><a href="#"><i class="ti-twitter-alt"></i>twitter/xyz</a></li>
                    </ul>
                </div>
           </div>
       </div>
   </div>
</body>
</html>