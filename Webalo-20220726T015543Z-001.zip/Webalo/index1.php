<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Diện Thoại</title>
    <link rel="stylesheet" href="./assets/fonts/themify-icons-font/themify-icons-font/themify-icons/themify-icons.css">
    <link rel="stylesheet" href="./assets/css/style.css">
    <style>
        #header{
            height: 500px;
            border: 1px solid #000;
        }
        #details-img{
            width: 30%;
            height: 370px;
            display: inline-block;
            border: 1px solid #000;
            float: left;
        }
        .details-image{
            width: -webkit-fill-available;
            height: -webkit-fill-available;
            display: inline-block;
            border: 1px solid #000;
            margin-top: 2px;
            margin-left: 2px;
        }
        #product-detail{
           margin-top: 3px;
            border: 1px solid #000;
        }
        #details-info{
            width: 30%;
            float: left;
            height: 370px;  
            border: 1px solid #000; 
            display: block;
            padding-top: 10px;
            padding-left: 10px;
        }
        #details-kt{
            width: 40%;
            float: right;
            height: 370px;   
            border: 1px solid #000;
            padding-top: 10px;
            padding-left: 10px;
        }
        .add-to-cart{
            text-align: center;
            width: 50px;
            height: 35px;
        }
        .add-to-cart a{
            text-decoration: none;
            color: #000;
            background-color: red;
            text-align: center;
            padding: 10px;
            
            margin-left: 70px;
        }
        .product-price{
            margin-left: 20px;
            display: block;
            font-weight: 800;
        }

    </style>
</head>
<body>
   <div id="main">
       <div id="top">
            <div id="logo">
                <a href="index.php" class="logo-web">
                    <img src="./assets/img/top/logo.jpg" alt="Đồng hồ thời thượng" class="img-logo">   
                </a>
            </div>
            <div id="search">
                <form action="">
                    <input type="text" placeholder="Bạn cần tìm gì ?">
                    <button class="btn-search ti-search"></button>
                </form>
            </div>
            <div id="nav-top">              
                <ul>
                    <li>
                        <a href="#">
                            <i class="icon-navtop ti-agenda"></i>
                            <div>
                                <span>Tin tức</span>
                                <p>Hot news</p>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="icon-navtop ti-mobile"></i>
                            <div>
                                <span>Gọi mua hàng</span>
                                <p>19001001</p>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="icon-navtop ti-location-pin"></i>
                            <div>
                                <span>Chuỗi cửa hàng</span>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="cart.php">
                            <i class="icon-navtop ti-shopping-cart"></i>
                            <div>
                                <span>Giỏ hàng</span>                              
                            </div>
                        </a>
                    </li>
                </ul>
            </div>
            <div id="login-top">
                <a href="login.php" class="icon-login-top ti-user">
                    <div>
                        <span>Đăng nhập</span>
                    </div>
                </a>
            </div>
       </div>
       
       <div id="header">
            <?php
                
                include 'config.php';
                $result=mysqli_query($link,"SELECT *FROM tbdongDH WHERE MaDongDH= ".$_GET['id']);
                $product=mysqli_fetch_assoc($result);
                
                
            ?>
            <div class="content">
                <div class="title">
                    <p><b><i>Chi tiết sản phẩm</i></b></p>
                </div>
                <div id="product-detail">
                    <div id="details-img">
                        <img src="./assets/image/<?=$product['HinhAnh']?>" class="details-image" alt="">
                    </div>
                    <div id="details-info">
                        <h1><?=$product['TenDongDH']?></h1>
                        <label><b>Giá : </b></label><span class="product-price"><?=number_format($product['DonGia'],0,",",".")?> đ</span><br/>
                        <form id="add-to-cart-form" action="cart.php?action=add" method="POST">
                            <input type="text" value="1" name="quantity[<?=$product['MaDongDH']?>]" size="2"/>
                            <input type="submit" value="Mua sản phẩm"/>
                        </form>
                        
                    </div>
                    <div id="details-kt">
                        <h3>Thông số kĩ thuật</h3>
                        <?=$product['ThongSo']?>
                    </div>
                    <div class="clear-both"></div>
                    
                </div>
            </div>
       </div>

       
       <div id="footer">
           <div class="cty">
            <p><b><i>Công ty cổ phần XYZ</i></b></p>
           </div>
           <div class="intro footercss">
                <p><b>Thông tin công ty</b></p>
                <div>
                    <p>Công ty cổ phần XYZ</p>
                    <p>Địa chỉ : Số 21 đường A Hà Nội</p>
                    <p>Ngày thành lập : 21/10/2021</p>
                </div>
           </div>
           <div class="advise footercss">
                <p><b>Hỗ trợ khách hàng</b></p>
                <div>
                    <p>Gọi mua hàng: <b style="color: blue;">085 5100 001</b></p>
                    <p>Hỗ trợ kĩ thuật: <b style="color: blue;">1800 6502</b></p>
                    <p>Gọi hợp tác kinh doanh:<b style="color: blue;"> 1900 6122</b></p>
                </div>
           </div>
           <div class="info footercss">
                <p><b>Thông tin liên hệ</b></p>
                <div class="info-nav">
                    <ul>
                        <li><a href="#"><i class="ti-facebook"></i>facebook/xyz</a></li>
                        <li><a href="#"><i class="ti-youtube"></i>youtube/xyz</a></li>
                        <li><a href="#"><i class="ti-twitter-alt"></i>twitter/xyz</a></li>
                    </ul>
                </div>
           </div>
       </div>
   </div>
</body>
</html>