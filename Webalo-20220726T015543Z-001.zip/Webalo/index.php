<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Đồng Hồ</title>
    <link rel="stylesheet" href="./assets/fonts/themify-icons-font/themify-icons-font/themify-icons/themify-icons.css">
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<style>
    input.form-index-input {
    width: 240px;
    height: 41px;
    margin-top: 1px;
    font-size: 25px;
    }
    input.form-index-input:hover{
        background-color: rgba(255,102, 0, 1);
        font-weight: 800;
    }
</style>
<body>
   <div id="main">
       <div id="top">
            <div id="logo">
                <a href="index.php" class="logo-web">
                    <img src="./assets/img/top/logo.jpg" alt="Đồng hồ thời thượng" class="img-logo">   
                </a>
            </div>
            <div id="search">
                <!-- <form action="index.php?action=search">
                    <input type="text" placeholder="Bạn cần tìm gì ?" name="name" value="<?=!empty($name)?$name:""?>">
                    <input type="submit" value="Tìm"/>
                    <button type="submit" class="btn-search ti-search"></button>
                </form> -->
                <form action="index.php?action=search" method="POST">
                        <fieldset>
                            <input type="text" placeholder="Bạn cần tìm gì ?" name="TenDongDH" value="<?=!empty($TenDongDH)?$TenDongDH:""?>"/>
                            <input type="submit" value="Tìm" style="width:43px"/>
                        </fieldset>
                    </form>
            </div>
            <div id="nav-top">              
                <ul>
                    <li>
                        <a href="#">
                            <i class="icon-navtop ti-agenda"></i>
                            <div>
                                <span>Tin tức</span>
                                <p>Hot news</p>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="icon-navtop ti-mobile"></i>
                            <div>
                                <span>Gọi mua hàng</span>
                                <p>19001001</p>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="icon-navtop ti-location-pin"></i>
                            <div>
                                <span>Chuỗi cửa hàng</span>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="cart.php">
                            <i class="icon-navtop ti-shopping-cart"></i>
                            <div>
                                <span>Giỏ hàng</span>                              
                            </div>
                        </a>
                    </li>
                </ul>
            </div>
            <div id="login-top">
                <a href="login.php">
                    <i class="icon-login-top ti-user"></i>
                    <div>
                        <span>Đăng nhập</span>
                    </div>
                </a>
            </div>
       </div>
       
       <div id="header">
            <div class="nav">
                <ul>
                    <li>
                        <form action="index.php?action=Casio" class="form-index" method="POST">                       
                        <input type="submit" class="form-index-input" value="Casio"/>                       
                        </form>
                    </li>
                    <li>
                        <form action="index.php?action=Citizen" class="form-index" method="POST">                       
                        <input type="submit" class="form-index-input" value="Citizen"/>                       
                        </form>
                    </li>
                    <li>
                        <form action="index.php?action=Orient" class="form-index" method="POST">                       
                        <input type="submit" class="form-index-input" value="Orient"/>                       
                        </form>
                    </li>
                    <li>
                        <form action="index.php?action=Seiko" class="form-index" method="POST">                       
                        <input type="submit" class="form-index-input" value="Seiko"/>                       
                        </form>
                    </li>
                    <li>
                        <form action="index.php?action=TISSOT" class="form-index" method="POST">                       
                        <input type="submit" class="form-index-input" value="TISSOT"/>                       
                        </form>
                    </li>
                    <li>
                        <form action="index.php?action=SRWatch" class="form-index" method="POST">                       
                        <input type="submit" class="form-index-input" value="SRWatch"/>                       
                        </form>
                    </li>
                    <li>
                        <form action="index.php?action=Bulova" class="form-index" method="POST">                       
                        <input type="submit" class="form-index-input" value="Bulova"/>                       
                        </form>
                    </li>
                    <li>
                        <form action="index.php?action=All" class="form-index" method="POST">                       
                        <input type="submit" class="form-index-input" value="Tất cả"/>                       
                        </form>
                    </li>
  
                </ul>
            </div>
            <div class="slider">
                <div class="slider-photo">
                    <img id="img" onclick="changImage()" src="./assets/img/header/slider/slider1.jpg" alt="">
                </div>
                <script>
                    var i=1;
                    changImage=function(){
                        var imgs = ["./assets/img/header/slider/slider2.jpg",
                        "./assets/img/header/slider/slider2.jpg",
                        "./assets/img/header/slider/slider3.jpg",
                        "./assets/img/header/slider/slider4.jpg"];
                        document.getElementById('img').src =imgs[i];
                        i++;
                        if(i==4){
                            i=0;
                        }
                    }
                    setInterval(changImage,1500);
                </script>
            </div>
            <div class="photo">
                <div class="photo-img">
                    <a href="index1.php?id=5"><img src="./assets/img/header/slider/slider1.jpg" class="img-qc" alt="Ảnh quảng cáo"></a>
                </div>
                <div class="photo-img mg-photo-img">
                    <a href="#"><img src="./assets/img/header/slider/slider2.jpg" class="img-qc" alt="Ảnh quảng cáo"></a>
                </div>
                <div class="photo-img">
                    <a href="index1.php?id=1"><img src="./assets/img/header/slider/slider3.jpg" class="img-qc" alt="Ảnh quảng cáo"></a>
                </div>
            </div>
       </div>

       <div id="content">
           <?php
                
                include 'config.php';
                if(!empty($_GET['action']) && $_GET['action'] == 'search' && !empty($_POST)){
                    // var_dump($_POST);exit;
                    $_SESSION['product_filter']= $_POST;
                    
                }
                if(!empty($_SESSION['product_filter'])){
                    // var_dump($_SESSION['product_filter']);exit;
                    $where = "";
                    foreach ($_SESSION['product_filter'] as $field => $value) {
                        
                        if(!empty($value)){
                            switch ($field) {
                                case 'TenDongDH':
                                $where= (!empty($where))? : "`".$field."` LIKE '%".$value."%'";
                                break;
                                
                            }
                        }
                        // var_dump($where);exit;
                    }
                    // var_dump($where);exit;
                    extract($_SESSION['product_filter']);
                    // var_dump($TenDongDH);exit;
                }
                if(isset($_GET['action'])){
                    $where="";
                    if(!empty($value)){
                        switch ($field) {
                            case 'TenDongDH':
                            $where= (!empty($where))? : "`".$field."` LIKE '%".$value."%'";
                            break;
                            
                        }
                    }
                    switch($_GET['action']){
                        
                        case "Casio":
                            $where=" MaHangSx = 1 ";           
                            break; 
                        case "Citizen":
                            $where=" MaHangSx = 2 ";           
                            break;
                        case "Orient":
                            $where=" MaHangSx = 3 ";           
                            break;
                        case "Seiko":
                            $where=" MaHangSx = 4 ";           
                            break;
                        case "#":
                            $where="";           
                            break;
                        case "#":
                            $where="";           
                            break;
                        case "#":
                            $where="";           
                            break;
                        case "All":
                            $where="";           
                            break;
                    }
                    
                   
                }
                // var_dump($where);exit;
                $item_per_page =!empty($_GET['per_page']) ? $_GET['per_page']:7; 
                
                $current_page=!empty($_GET['page'])?$_GET['page']:1;
                
                $offset=($current_page -1)*$item_per_page;
                if(!empty($where)){
                    $products = mysqli_query($link, "SELECT * FROM tbdongDH where (".$where.") ORDER BY MaDongDH DESC LIMIT " . $item_per_page . " OFFSET " . $offset);
                    // var_dump($products);exit;
                }else{
                    $products = mysqli_query($link, "SELECT * FROM tbdongDH ORDER BY MaDongDH DESC LIMIT " . $item_per_page . " OFFSET " . $offset);
                }
                // $products=mysqli_query($link,"SELECT *FROM tbdongDH ORDER BY MaDongDH ASC LIMIT ".$item_per_page." OFFSET ".$offset);
                $totalRecords=mysqli_query($link,"SELECT * FROM tbdongDH");
                $totalRecords=$totalRecords->num_rows;
                $totalPages=ceil($totalRecords/$item_per_page);
           ?>
           <div class="content">
               <div class="title">
                    <p><b><i>Đồng Hồ Nổi Bật</i></b></p>
               </div>
               <div class="nav-content">
                    <?php 
                        // for($i=1;$i<=10;$i++) { 
                        while ($row = mysqli_fetch_array($products)) {
                    ?>
                    <div class="product-item">
                        
                        <div class="product-img">
                        <a href="./index1.php?id=<?=$row['MaDongDH']?>"><img src="./assets/image/<?=$row['HinhAnh']?>" class="img-ct" title="<?=$row['TenDongDH']?>"/></a>
                        </div>
                        <strong><a id="xyz" href="./index1.php?id=<?=$row['MaDongDH']?>"><?=$row['TenDongDH']?></a></strong><br/>
                        <label>Giá : </label><span class="product-price"><?=number_format($row['DonGia'],0,",",".")?> đ</span><br/>
                        <div class="btn-buy">
                            <a href="./index1.php?id=<?=$row['MaDongDH']?>">Mua hàng</a>
                        </div>
                    </div>
                    <?php } ?>
                    <div class="clear-both"></div>
                    <?php
                        include './pagination.php';
                    ?>
                    <div class="clear-both"></div>
               </div>
           </div>
           
       </div>
       <div id="content">
           <?php
                
                
                $item_per_page =!empty($_GET['per_page']) ? $_GET['per_page']:5; 
                
                $current_page=!empty($_GET['page'])?$_GET['page']:1;
                
                $offset=($current_page -1)*$item_per_page;
                $products=mysqli_query($link,"SELECT *FROM tbdongDH ORDER BY MaDongDH ASC LIMIT ".$item_per_page." OFFSET ".$offset);
                $totalRecords=mysqli_query($link,"SELECT * FROM tbdongDH");
                $totalRecords=$totalRecords->num_rows;
                $totalPages=ceil($totalRecords/$item_per_page);
           ?>
           <div class="content">
               <div class="title">
                    <p><b><i>Giá Sốc Hôm Nay</i></b></p>
               </div>
               <div class="nav-content">
                    <?php 
                        // for($i=1;$i<=10;$i++) { 
                        while ($row = mysqli_fetch_array($products)) {
                    ?>
                    <div class="product-item">
                        
                        <div class="product-img">
                        <a href="./index1.php?id=<?=$row['MaDongDH']?>"><img src="./assets/image/<?=$row['HinhAnh']?>" class="img-ct" title="<?=$row['TenDongDH']?>"/></a>
                        </div>
                        <strong><a id="xyz" href="./index1.php?id=<?=$row['MaDongDH']?>"><?=$row['TenDongDH']?></a></strong><br/>
                        <label>Giá : </label><span class="product-price"><?=number_format($row['DonGia'],0,",",".")?> đ</span><br/>
                        <div class="btn-buy">
                            <a href="./index1.php?id=<?=$row['MaDongDH']?>">Mua hàng</a>
                        </div>
                    </div>
                    <?php } ?>
                    <div class="clear-both"></div>
                    <?php
                        include './pagination.php';
                    ?>
                    <div class="clear-both"></div>
               </div>
           </div>
           
       </div>

       <div id="footer">
           <div class="cty">
            <p><b><i>Công ty cổ phần XYZ</i></b></p>
           </div>
           <div class="intro footercss">
                <p><b>Thông tin công ty</b></p>
                <div>
                    <p>Công ty cổ phần XYZ</p>
                    <p>Địa chỉ : Số 21 đường A Hà Nội</p>
                    <p>Ngày thành lập : 21/10/2021</p>
                </div>
           </div>
           <div class="advise footercss">
                <p><b>Hỗ trợ khách hàng</b></p>
                <div>
                    <p>Gọi mua hàng: <b style="color: blue;">085 5100 001</b></p>
                    <p>Hỗ trợ kĩ thuật: <b style="color: blue;">1800 6502</b></p>
                    <p>Gọi hợp tác kinh doanh:<b style="color: blue;"> 1900 6122</b></p>
                </div>
           </div>
           <div class="info footercss">
                <p><b>Thông tin liên hệ</b></p>
                <div class="info-nav">
                    <ul>
                        <li><a href="#"><i class="ti-facebook"></i>facebook/xyz</a></li>
                        <li><a href="#"><i class="ti-youtube"></i>youtube/xyz</a></li>
                        <li><a href="#"><i class="ti-twitter-alt"></i>twitter/xyz</a></li>
                    </ul>
                </div>
           </div>
       </div>
   </div>
</body>
</html>