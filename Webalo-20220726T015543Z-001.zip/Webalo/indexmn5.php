<?php
include 'header.php';
// if (!empty($_SESSION['current_user'])) {
    
    if(!empty($_GET['action']) && $_GET['action'] == 'search' && !empty($_POST)){
        // var_dump($_POST);exit;
        $_SESSION['product_filter']= $_POST;
        
    }
    if(!empty($_SESSION['product_filter'])){
        // var_dump($_SESSION['product_filter']);exit;
        $where = "";
        foreach ($_SESSION['product_filter'] as $field => $value) {
            
            if(!empty($value)){
                switch ($field) {
                    case 'order_id':
                    $where .= (!empty($where))? " AND "."`".$field."` = ".$value."": "`".$field."` = ".$value."";
                    break;
                    default:
                    $where .= (!empty($where))? " AND "."`".$field."` = ".$value."": "`".$field."` = ".$value."";
                    break;
                }
            }
            // var_dump($where);exit;
        }
        // var_dump($where);exit;
        extract($_SESSION['product_filter']);
        // var_dump($name);exit;
    }
    $item_per_page = (!empty($_GET['per_page'])) ? $_GET['per_page'] : 5;
    $current_page = (!empty($_GET['page'])) ? $_GET['page'] : 1;
    $offset = ($current_page - 1) * $item_per_page;
    if(!empty($where)){
        $totalRecords = mysqli_query($link, "SELECT * FROM chitietdonhang where (".$where.")");
    }else{
        $totalRecords = mysqli_query($link, "SELECT * FROM chitietdonhang");
    }
    $totalRecords = $totalRecords->num_rows;
    $totalPages = ceil($totalRecords / $item_per_page);
    if(!empty($where)){
        $products = mysqli_query($link, "SELECT * FROM chitietdonhang where (".$where.") ORDER BY id DESC LIMIT " . $item_per_page . " OFFSET " . $offset);
        // var_dump($products);exit;
    }else{
        $products = mysqli_query($link, "SELECT * FROM chitietdonhang ORDER BY id DESC LIMIT " . $item_per_page . " OFFSET " . $offset);
    }
    // $products = mysqli_query($link, "SELECT * FROM chitietdonhang ORDER BY id DESC LIMIT " . $item_per_page . " OFFSET " . $offset);

    mysqli_close($link);
    ?>
    <div class="main-content" style="width: 979px">
        <h1>Danh sách chi tiết đơn hàng</h1>
        <div class="product-items">
            <div class="buttons">
                <a href="create5.php">Thêm chi tiết đơn hàng</a>
            </div>
            
            <div class="product-search">
                    <form action="indexmn5.php?action=search" method="POST">
                        <fieldset>
                            <legend>Tìm kiếm chi tiết đơn hàng:</legend>
                            ID: <input type="text" name="id" value="<?=!empty($id)?$id:""?>"/>
                            Order_id: <input type="text" name="order_id" value="<?=!empty($order_id)?$order_id:""?>"/>
                            <input type="submit" value="Tìm"/>
                        </fieldset>
                    </form>
            </div>
            <div class="total-items">
                <span>Có tất cả <strong><?=$totalRecords?></strong> chi tiết đơn hàng trên <strong><?=$totalPages?></strong> trang</span>
            </div>
            <ul>
                <li class="product-item-heading">
                    <div class="product-prop product-id">ID</div>
                    <div class="product-prop product-name" style="width: 70px">order_id</div>
                    <div class="product-prop product-id" style="width: 70px">product_id</div>
                    <div class="product-prop product-price">price</div>
                    <div class="product-prop product-name" style="width: 81px">quantity</div>
                  
                    
                    <div class="product-prop product-time" style="width: 120px">Ngày tạo</div>
                    <div class="product-prop product-time" style="width: 120px">Ngày cập nhật</div>
                    <div class="product-prop product-button">
                        Xóa
                    </div>
                    <div class="product-prop product-button">
                        Sửa
                    </div>
                    <div class="product-prop product-button">
                        Xem
                    </div>
                    
                    <div class="clear-both"></div>
                </li>
                <?php
                while ($row = mysqli_fetch_array($products)) {
                    ?>
                    <li>
                        <div class="product-prop product-id"><?= $row['id'] ?></div>
                        <div class="product-prop product-name" style="width: 70px"><?= $row['order_id'] ?></div>
                        <div class="product-prop product-id" style="width: 70px"><?= $row['product_id'] ?></div>
                        <div class="product-prop product-price"><?=number_format($row['price'],0,",",".")?></div>
                        <div class="product-prop product-name" style="width: 81px"><?= $row['quantity'] ?></div>                    
                 
                        
                        <div class="product-prop product-time" style="width: 120px"><?= date('d/m/Y H:i', $row['created_time']) ?></div>
                        <div class="product-prop product-time" style="width: 120px"><?= date('d/m/Y H:i', $row['last_updated']) ?></div>
                        <div class="product-prop product-button">
                            <a href="delete5.php?id=<?= $row['id'] ?>">Xóa</a>
                        </div>
                        <div class="product-prop product-button">
                            <a href="update5.php?id=<?= $row['id'] ?>">Sửa</a>
                        </div>
                        <div class="product-prop product-button">
                            <a href="read5.php?id=<?= $row['id'] ?>">Xem</a>
                        </div>
                        
                        <div class="clear-both"></div>
                    </li>
                <?php } ?>
            </ul>
            <?php
            include './pagination.php';
            ?>
            <div class="clear-both"></div>
        </div>
    </div>
    <?php
// }
include './footer.php';
?>