<?php
    require_once 'config.php';
    if(isset($_POST["submit"]) && $_POST["username"]!='' && $_POST["password"]!=''){
        $username=$_POST["username"];
        $password=$_POST["password"];
        $sql="SELECT *FROM tbkhachhang WHERE UserName='$username' AND Password='$password'";
        $result=mysqli_query($link,$sql);
        if(mysqli_num_rows($result)>0){
             header("location: index.php");
        }else{
            
                $sql="SELECT *FROM tbnhanvien WHERE UserName='$username' AND Password='$password' AND QuyenTruyCap='admin'";
                $result=mysqli_query($link,$sql);
                if(mysqli_num_rows($result)>0){
                     header("location: product_listing.php");
                }else{
                    echo "<script type='text/javascript'>alert('đăng nhập không thành công');</script>";
                }
            
        }
        if ($result->num_rows > 0) {
            $user = mysqli_fetch_assoc($result);
            if (session_status() == PHP_SESSION_NONE) {
                session_start();
            }
            $_SESSION['current_user'] = $user;
            
        }
    }else{
        header("location: login.php");
    }
?>