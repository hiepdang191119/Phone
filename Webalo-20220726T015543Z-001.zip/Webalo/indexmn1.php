<?php
include 'header.php';
// if (!empty($_SESSION['current_user'])) {
    
    if(!empty($_GET['action']) && $_GET['action'] == 'search' && !empty($_POST)){
        
        $_SESSION['product_filter']= $_POST;
        
    }
    if(!empty($_SESSION['product_filter'])){
       
        $where = "";
        foreach ($_SESSION['product_filter'] as $field => $value) {
            
            if(!empty($value)){
                switch ($field) {
                    case 'TenKH':
                    $where .= (!empty($where))? " AND "."`".$field."` LIKE '%".$value."%'" : "`".$field."` LIKE '%".$value."%'";
                    break;
                    default:
                    $where .= (!empty($where))? " AND "."`".$field."` = ".$value."": "`".$field."` = ".$value."";
                    break;
                }
            }
            
        }
        
        extract($_SESSION['product_filter']);
       
    }
    $item_per_page = (!empty($_GET['per_page'])) ? $_GET['per_page'] : 5;
    $current_page = (!empty($_GET['page'])) ? $_GET['page'] : 1;
    $offset = ($current_page - 1) * $item_per_page;
    if(!empty($where)){
        $totalRecords = mysqli_query($link, "SELECT * FROM tbkhachhang where (".$where.")");
    }else{
        $totalRecords = mysqli_query($link, "SELECT * FROM tbkhachhang");
    }
    $totalRecords = $totalRecords->num_rows;
    $totalPages = ceil($totalRecords / $item_per_page);
    if(!empty($where)){
        $products = mysqli_query($link, "SELECT * FROM tbkhachhang where (".$where.") ORDER BY MaKH ASC LIMIT " . $item_per_page . " OFFSET " . $offset);
        
    }else{
        $products = mysqli_query($link, "SELECT * FROM tbkhachhang ORDER BY MaKH ASC LIMIT " . $item_per_page . " OFFSET " . $offset);
    }

    mysqli_close($link);
    ?>
    <div class="main-content">
        <h1>Danh sách khách hàng</h1>
        <div class="product-items">
            <div class="buttons">
                <a href="create1.php">Thêm khách hàng</a>
            </div>
            
            <div class="product-search">
                    <form action="indexmn1.php?action=search" method="POST">
                        <fieldset>
                            <legend>Tìm kiếm khách hàng:</legend>
                            ID: <input type="text" name="MaKH" value="<?=!empty($MaKH)?$MaKH:""?>"/>
                            Tên khách hàng: <input type="text" name="TenKH" value="<?=!empty($TenKH)?$TenKH:""?>"/>
                            <input type="submit" value="Tìm"/>
                        </fieldset>
                    </form>
            </div>
            <div class="total-items">
                <span>Có tất cả <strong><?=$totalRecords?></strong> khách hàng trên <strong><?=$totalPages?></strong> trang</span>
            </div>
            <ul>
                <li class="product-item-heading">
                    <div class="product-prop product-id">ID</div>
                    
                    <div class="product-prop product-name" style="width:120px">Tên khách hàng</div>
                    <div class="product-prop product-name" style="width:75px">UserName</div>
                    <div class="product-prop product-name" style="width:66px">Password</div>
                    <div class="product-prop product-name" style="width:165px">Email</div>
                    <div class="product-prop product-name" style="width:200px">DiaChi</div>
                    <div class="product-prop product-name" style="width:60px">SoDT</div>

                    
                    <div class="product-prop product-button">
                        Xóa
                    </div>
                    <div class="product-prop product-button">
                        Sửa
                    </div>
                    <div class="product-prop product-button">
                        Xem
                    </div>
                    
                    <div class="clear-both"></div>
                </li>
                <?php
                while ($row = mysqli_fetch_array($products)) {
                    ?>
                    <li>
                        <div class="product-prop product-id"><?= $row['MaKH'] ?></div>
                        <div class="product-prop product-name" style="width:120px"><?= $row['TenKH'] ?></div>
                        <div class="product-prop product-name" style="width:75px"><?= $row['UserName'] ?></div>
                        <div class="product-prop product-name" style="width:66px"><?= $row['Password'] ?></div>
                        <div class="product-prop product-name" style="width:165px"><?= $row['Email'] ?></div>
                        <div class="product-prop product-name" style="width:200px"><?= $row['DiaChi'] ?></div>
                        <div class="product-prop product-name" style="width:60px"><?= $row['SoDT'] ?></div>
                        <div class="product-prop product-button">
                            <a href="delete1.php?id=<?= $row['MaKH'] ?>">Xóa</a>
                        </div>
                        <div class="product-prop product-button">
                            <a href="update1.php?id=<?= $row['MaKH'] ?>">Sửa</a>
                        </div>
                        <div class="product-prop product-button">
                            <a href="read1.php?id=<?= $row['MaKH'] ?>">Xem</a>
                        </div>
                        
                        <div class="clear-both"></div>
                    </li>
                <?php } ?>
            </ul>
            <?php
            include './pagination.php';
            ?>
            <div class="clear-both"></div>
        </div>
    </div>
    <?php
// }
include './footer.php';
?>