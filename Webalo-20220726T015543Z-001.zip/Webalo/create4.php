<?php
    require_once 'config.php';
    $name=$phone=$address=$note=$total=$created_time=$last_updated="";
    $name_err=$phone_err=$address_err=$note_err=$total_err=$created_time_err=$last_updated_err="";
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        
        $input_name = trim($_POST["name"]);
        if(empty($input_name)){
            $name_err="Please enter a name.";
        } elseif(!filter_var(trim($_POST["name"]),FILTER_VALIDATE_REGEXP,
            array("options"=>array("regexp"=>"/^[a-zA-Z'-.\s ]+$/")))){
                $name_err='Please enter a valid name.';
            }else{
                $name=$input_name;
            }
        $input_phone=trim($_POST["phone"]);
        if(empty($input_phone)){
            $phone_err='Please enter an phone';
        }else{
            $phone=$input_phone;
        }
        $input_address=trim($_POST["address"]);
        if(empty($input_address)){
            $address_err='Please enter an address';
        }else{
            $address=$input_address;
        }
        $input_note=trim($_POST["note"]);
        if(empty($input_note)){
            $note_err='Please enter an note';
        }else{
            $note=$input_note;
        }
        $input_total=trim($_POST["total"]);
        if(empty($input_total)){
            $total_err='Please enter an total';
        }else{
            $total=$input_total;
        }
        $input_created_time=trim($_POST["created_time"]);
        if(empty($input_created_time)){
            $created_time_err='Please enter an created_time';
        }else{
            $created_time=$input_created_time;
        }
        $input_last_updated=trim($_POST["last_updated"]);
        if(empty($input_last_updated)){
            $last_updated_err='Please enter an last_updated';
        }else{
            $last_updated=$input_last_updated;
        }
        

        if(empty($name_err) && empty($phone_err) && empty($address_err) && empty($note_err) && empty($total_err) && empty($created_time_err) && empty($last_updated_err)){
            $sql="INSERT INTO donhang (name,phone,address,note,total,created_time,last_updated) VALUES(?,?,?,?,?,?,?)";
            if($stmt=mysqli_prepare($link,$sql)){
                mysqli_stmt_bind_param($stmt,"ssssssd",$param_name,$param_phone,$param_address,$param_note,$param_total,$param_created_time,$param_last_updated);
                
                $param_name=$name;
                $param_phone=$phone;
                $param_address=$address;
                $param_note=$note;
                $param_total=$total;
                $param_created_time=$created_time;
                $param_last_updated=$last_updated;
                
                if(mysqli_stmt_execute($stmt)){
                    header("location: indexmn4.php");
                    exit();
                }else{
                    echo "Something went wrong. Please try agian later.";
                }
            }
            mysqli_stmt_close($stmt);
        }
        mysqli_close($link);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <title>Document</title>
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Create Record</h2>
                    </div>
                    <p>Please fill this form and submit to add tbnhanvien record to the database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                           
                        <div class="form-group <?php echo(!empty($name_err)) ? 'has-error' : ''; ?>">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control" value="">
                            <span class="help-block"><?php echo $name_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($phone_err)) ? 'has-error' : ''; ?>">
                            <label>phone</label>
                            <input type="number" name="phone" class="form-control" value="">
                            <span class="help-block"><?php echo $phone_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($address_err)) ? 'has-error' : ''; ?>">
                            <label>address</label>
                            <input type="text" name="address" class="form-control" value="">
                            <span class="help-block"><?php echo $address_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($note_err)) ? 'has-error' : ''; ?>">
                            <label>note</label>
                            <input type="text" name="note" class="form-control" value="">
                            <span class="help-block"><?php echo $note_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($total_err)) ? 'has-error' : ''; ?>">
                            <label>total</label>
                            <input type="number" name="total" class="form-control" value="">
                            <span class="help-block"><?php echo $total_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($last_updated_err)) ? 'has-error' : ''; ?>">
                            <label>last_updated</label>
                            <input type="text" name="last_updated" class="form-control" value="">
                            <span class="help-block"><?php echo $last_updated_err ;?></span>
                        </div>
                        
                        <div class="form-group <?php echo(!empty($created_time_err)) ? 'has-error' : ''; ?>">
                            <label>created_time</label>
                            <input type="text" name="created_time" class="form-control" value="">
                            <span class="help-block"><?php echo $created_time_err ;?></span>
                        </div>
                        
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="indexmn4.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>