<?php
include 'header.php';
// if (!empty($_SESSION['current_user'])) {
    $total1=0;
    $num=0; 
    $productabc=mysqli_query($link,"SELECT * FROM donhang");
    if(!empty($_GET['action']) && $_GET['action'] == 'search' && !empty($_POST)){
        // var_dump($_POST);exit;
        $_SESSION['product_abc']= $_POST;
        
    }
    if(!empty($_SESSION['product_abc'])){
        // var_dump($_SESSION['product_abc']);exit;
        $date = "";$month = "";$year = "";
        foreach ($_SESSION['product_abc'] as $field => $value) {
            
            if(!empty($value)){
                switch ($field) {
                    case 'date':
                        $date=$value;
                        break;
                    case 'month':
                        $month=$value;
                        break;
                    case 'year':
                        $year=$value;
                        break;
                }
            }
            // var_dump($where);exit;
        }
        // var_dump($date); var_dump($month); var_dump($year);exit;
        extract($_SESSION['product_abc']);
        // var_dump($TenDongDT);exit;
                 
        while ($row = mysqli_fetch_array($productabc)) {
            if($date==date('d', $row['created_time']) && $month==date('m', $row['created_time']) && $year==date('Y', $row['created_time']) && $row['status']=="ok"){
                $total1+=$row['total'];$num++;
                // var_dump($total1);exit;
            }elseif($date=="" && $month==date('m', $row['created_time']) && $year==date('Y', $row['created_time']) && $row['status']=="ok"){
                $total1+=$row['total'];$num++;
                // var_dump($total1);exit;
            }elseif($date=="" && $month=="" &&  $year==date('Y', $row['created_time'])  && $row['status']=="ok" ){
                $total1+=$row['total'];$num++;
                // var_dump($total1);exit;
            }           
        }
        // var_dump($total1);exit;
       
    } 
       
    
    
    
    $total=mysqli_query($link,"SELECT SUM(total) total FROM donhang where status='ok'");
    $count_donhang=mysqli_query($link,"SELECT COUNT(id) count_donhang FROM donhang where status='ok' " );
    
    $row = mysqli_fetch_array($productabc);
    $row2 = mysqli_fetch_array($total);
    $row1 = mysqli_fetch_array($count_donhang);
    mysqli_close($link);
    ?>
    <div class="main-content">
        <h1>Chi tiết thống kê</h1>
        <div class="product-items">
            <p>Tổng doanh thu: <b><?=number_format($row2['total'],0,",",".")?> đ</b></p>
            <p>Tổng đơn đã bán: <b><?=$row1['count_donhang']?></b></p>
        </div>
        <div class="product-items">
            <div class="product-search">
                    <form action="indexmn6.php?action=search" method="POST">
                        <fieldset>
                            <legend>Tìm kiếm tổng doanh thu:</legend>
                            Ngày : <input type="number" size="1" name="date" value="<?=!empty($date)?$date:""?>"/>
                            Tháng : <input type="number" size="1" name="month" value="<?=!empty($month)?$month:""?>"/>
                            Năm : <input type="number" size="1" name="year" value="<?=!empty($year)?$year:""?>"/>
                            <input type="submit" value="Tìm"/>
                            <p>Tổng doanh thu: <b><?=number_format($total1,0,",",".")?> đ</b></p>
                            <p>Tổng đơn đã bán: <b><?=$num?></b></p>
                        </fieldset>
                    </form>
            </div>
            
            <div class="clear-both"></div>
        </div>
       

    </div>
    <?php
// }
include './footer.php';
?>