<?php
    require_once 'config.php';
    $name=$username=$password=$email=$address=$phone="";
    $name_err=$username_err=$password_err=$email_err=$address_err=$phone_err="";
    if(isset($_POST["id"])&& !empty($_POST["id"])){
        $id=$_POST["id"];
        $input_name=trim($_POST["name"]);
        if(empty($input_name)){
            $name_err="Please enter a name";
        }elseif(!filter_var(trim($_POST["name"]),FILTER_VALIDATE_REGEXP,
        array("options"=>array("regexp"=>"/^[a-zA-Z'-.\s ]+$/")))){
            $name_err='Please enter a valid name.';
        }else{
            $name=$input_name;
        }
        $input_username=trim($_POST["username"]);
        if(empty($input_username)){
            $username_err='Please enter an username';
        }else{
            $username=$input_username;
        }
        $input_password=trim($_POST["password"]);
        if(empty($input_password)){
            $password_err='Please enter an password';
        }else{
            $password=$input_password;
        }
        
        $input_email=trim($_POST["email"]);
        if(empty($input_email)){
            $email_err='Please enter an email';
        }else{
            $email=$input_email;
        }
        $input_address=trim($_POST["address"]);
        if(empty($input_address)){
            $address_err='Please enter an address';
        }else{
            $address=$input_address;
        }
        $input_phone=trim($_POST["phone"]);
        if(empty($input_phone)){
            $phone_err='Please enter an phone';
        }elseif(!filter_var(trim($_POST["phone"]),FILTER_VALIDATE_REGEXP,
        array("options"=>array("regexp"=>"/^[0-9]+$/")))){
            $phone_err='Please enter a valid phone.';
        }else{
            $phone=$input_phone;
        }

        if(empty($name_err) && empty($username_err) && empty($password_err)  && empty($email_err) && empty($address_err) && empty($phone_err)){
            $sql="UPDATE tbkhachhang SET TenKH=?,UserName=?,Password=?,Email=?,DiaChi=?,SoDT=? WHERE MaKH=?";
            if($stmt=mysqli_prepare($link,$sql)){
                mysqli_stmt_bind_param($stmt,"ssssssi",$param_name,$param_username,$param_password,$param_email,$param_address,$param_phone,$param_id);
                $param_name=$name;
                $param_username=$username;
                $param_password=$password;
               
                $param_email=$email;
                $param_address=$address;
                $param_phone=$phone;
                $param_id=$id;
                if(mysqli_stmt_execute($stmt)){
                    header("location: indexmn1.php");
                    exit();
                }else{
                    echo "Something went wrong. Please try agian later.";
                }
            }
            mysqli_stmt_close($stmt);
        }
        mysqli_close($link);
    }else{
        if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
            $id=trim($_GET["id"]);
            $sql="SELECT * FROM tbkhachhang WHERE MaKH =?";
            if($stmt =mysqli_prepare($link,$sql)){
                mysqli_stmt_bind_param($stmt,"i",$param_id);
                $param_id=$id;
                if(mysqli_stmt_execute($stmt)){
                    $result = mysqli_stmt_get_result($stmt);
                    if(mysqli_num_rows($result)==1){
                        $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
                        $name = $row["TenKH"];
                        $username = $row["UserName"];
                        $password = $row["Password"];
                        
                        $email = $row["Email"];
                        $address = $row["DiaChi"];
                        $phone = $row["SoDT"];
                    }
                    else
                    {
                        header("location:error.php");
                        exit();
                    }
                }else{
                    echo "Oops! Something went wrong. Please try again later.";
                }
            }
            mysqli_stmt_close($stmt);
            mysqli_close($link);
        }
        else{
            header("location:error.php");
            exit();
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <title>Document</title>
    <style>
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Update Record</h2>          
                    </div>
                    <p>Please edit the input values and to update the record.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group <?php echo(!empty($name_err)) ? 'has-error' : ''; ?>">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo $name; ?>">
                            <span class="help-block"><?php echo $name_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($username_err)) ? 'has-error' : ''; ?>">
                            <label>UserName</label>
                            <input type="text" name="username" class="form-control" value="<?php echo $username; ?>">
                            <span class="help-block"><?php echo $username_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($password_err)) ? 'has-error' : ''; ?>">
                            <label>Password</label>
                            <input type="text" name="password" class="form-control" value="<?php echo $password; ?>">
                            <span class="help-block"><?php echo $password_err ;?></span>
                        </div>
                        
                        <div class="form-group <?php echo(!empty($email_err)) ? 'has-error' : ''; ?>">
                            <label>email</label>
                            <input type="text" name="email" class="form-control" value="<?php echo $email; ?>">
                            <span class="help-block"><?php echo $email_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($address_err)) ? 'has-error' : ''; ?>">
                            <label>Address</label>
                            <input type="text" name="address" class="form-control" value="<?php echo $address; ?>">
                            <span class="help-block"><?php echo $address_err ;?></span>
                        </div>           
                        <div class="form-group <?php echo(!empty($phone_err)) ? 'has-error' : ''; ?>">
                            <label>Phone</label>
                            <input type="text" name="phone" class="form-control" value="<?php echo $phone; ?>">
                            <span class="help-block"><?php echo $phone_err ;?></span>
                        </div>
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="indexmn1.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>