
<?php
     require_once 'config.php';
    if(isset($_POST['submit']) && $_POST["name"] !='' && $_POST["username"] !='' && $_POST["password"] !='' && $_POST["repassword"] !='' && $_POST["email"] !='' && $_POST["address"] !='' && $_POST["phone"] !=''){
        $name=$_POST["name"];
        $username=$_POST["username"];
        $password=$_POST["password"];
        $repassword=$_POST["repassword"];
        $email=$_POST["email"];
        $address=$_POST["address"];
        $phone=$_POST["phone"];
        if($password != $repassword){
            echo "ko trùng pass";
            
        }
        elseif(
            $sql="SELECT * FROM tbkhachhang WHERE UserName='$username' "){
                $abc = mysqli_query($link,$sql);
            if(mysqli_num_rows($abc)>0){
                echo "có ten trùng";
            }else{ $sql="INSERT INTO tbkhachhang (TenKH,UserName,Password,Email,DiaChi,SoDT) VALUES ('$name','$username','$password','$email','$address','$phone')";
                mysqli_query($link,$sql);
                echo "đk tc";
            }
            
        }
        
    }
    else{
        echo "lỗi";
    }
?>
<?php
    // require_once 'config.php';
    // $name=$username=$password=$repassword=$email=$address=$phone="";
    // $name_err=$username_err=$password_err=$repassword_err=$email_err=$address_err=$phone_err="";
    // if($_SERVER["REQUEST_METHOD"]=="POST"){
        
    //     $input_name = trim($_POST["name"]);
    //     if(empty($input_name)){
    //         $name_err="Please enter a name.";
    //     } elseif(!filter_var(trim($_POST["name"]),FILTER_VALIDATE_REGEXP,
    //         array("options"=>array("regexp"=>"/^[a-zA-Z'-.\s ]+$/")))){
    //             $name_err='Please enter a valid name.';
    //         }else{
    //             $name=$input_name;
    //         }
    //     $input_username=trim($_POST["username"]);
    //     if(empty($input_username)){
    //         $username_err='Please enter an username';
    //     }else{
    //         $username=$input_username;
    //     }
    //     $input_password=trim($_POST["password"]);
    //     if(empty($input_password)){
    //         $password_err='Please enter an password';
    //     }else{
    //         $password=$input_password;
    //     }    
    //     $input_repassword=trim($_POST["repassword"]);
    //     if(empty($input_repassword)){
    //         $repassword_err='Please enter an repassword';
    //     }else{
    //         $repassword=$input_repassword;
    //     }     
    //     $input_email=trim($_POST["email"]);
    //     if(empty($input_email)){
    //         $email_err='Please enter an email';
    //     }else{
    //         $email=$input_email;
    //     }
    //     $input_address=trim($_POST["address"]);
    //     if(empty($input_address)){
    //         $address_err='Please enter an address';
    //     }else{
    //         $address=$input_address;
    //     }
    //     $input_phone=trim($_POST["phone"]);
    //     if(empty($input_phone)){
    //         $phone_err='Please enter an phone';
    //     }else{
    //         $phone=$input_phone;
    //     }

    //     if($password != $repassword){
    //         echo "ko trùng pass";
    //     }

    //     $sql="SELECT * FROM tbkhachhang WHERE UserName='$username' ";
    //     $abc = mysqli_query($link,$sql);
    //     if(mysqli_num_rows($abc)>0){
    //         echo "có ten trùng";
    //     }

    //     if(empty($name_err) && empty($username_err) && empty($password_err)  && empty($email_err) && empty($address_err) && empty($phone_err)){
    //         $sql="INSERT INTO tbkhachhang (TenKH,UserName,Password,Email,DiaChi,SoDT) VALUES(?,?,?,?,?,?)";
    //         if($stmt=mysqli_prepare($link,$sql)){
    //             mysqli_stmt_bind_param($stmt,"sssssd",$param_name,$param_username,$param_password,$param_email,$param_address,$param_phone);
     
    //             $param_name=$name;
    //             $param_username=$username;
    //             $param_password=$password;
               
    //             $param_email=$email;
    //             $param_address=$address;
    //             $param_phone=$phone;
    //             if(mysqli_stmt_execute($stmt)){
    //                 header("location: index.html");
    //                 exit();
    //             }else{
    //                 echo "Something went wrong. Please try agian later.";
    //             }
    //         }
    //         mysqli_stmt_close($stmt);
    //     }
    //     mysqli_close($link);
    // }
?>