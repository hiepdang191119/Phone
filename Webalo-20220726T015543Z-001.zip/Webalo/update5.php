<?php
    require_once 'config.php';
    $order_id=$product_id=$price=$quantity=$created_time=$last_updated="";
    $order_id_err=$product_id_err=$price_err=$quantity_err=$created_time_err=$last_updated_err="";
    if(isset($_POST["id"])&& !empty($_POST["id"])){
        $id=$_POST["id"];
        
        $input_order_id=trim($_POST["order_id"]);
        if(empty($input_order_id)){
            $order_id_err='Please enter an order_id';
        }else{
            $order_id=$input_order_id;
        }
        $input_product_id=trim($_POST["product_id"]);
        if(empty($input_product_id)){
            $product_id_err='Please enter an product_id';
        }else{
            $product_id=$input_product_id;
        }
        $input_price=trim($_POST["price"]);
        if(empty($input_price)){
            $price_err='Please enter an price';
        }else{
            $price=$input_price;
        }
        $input_quantity=trim($_POST["quantity"]);
        if(empty($input_quantity)){
            $quantity_err='Please enter an quantity';
        }else{
            $quantity=$input_quantity;
        }
        $input_created_time=trim($_POST["created_time"]);
        if(empty($input_created_time)){
            $created_time_err='Please enter an created_time';
        }else{
            $created_time=$input_created_time;
        }
        $input_last_updated=trim($_POST["last_updated"]);
        if(empty($input_last_updated)){
            $last_updated_err='Please enter an last_updated';
        }else{
            $last_updated=$input_last_updated;
        }
       

        if(empty($order_id_err) && empty($product_id_err) && empty($quantity_err) && empty($created_time_err) && empty($last_updated_err)){
            $sql="UPDATE chitietdonhang SET order_id=?,product_id=?,price=?,quantity=?,created_time=?,last_updated=? WHERE id=?";
            if($stmt=mysqli_prepare($link,$sql)){
                mysqli_stmt_bind_param($stmt,"ssssssi",$param_order_id,$param_product_id,$param_price,$param_quantity,$param_created_time,$param_last_updated,$param_id);
                
                $param_order_id=$order_id;
                $param_product_id=$product_id;
                $param_price=$price;
                $param_quantity=$quantity;
                $param_created_time=$created_time;
                $param_last_updated=$last_updated;
                
                $param_id=$id;
                if(mysqli_stmt_execute($stmt)){
                    header("location: indexmn5.php");
                    exit();
                }else{
                    echo "Something went wrong. Please try agian later.";
                }
            }
            mysqli_stmt_close($stmt);
        }
        mysqli_close($link);
    }else{
        if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
            $id=trim($_GET["id"]);
            $sql="SELECT * FROM chitietdonhang WHERE id =?";
            if($stmt =mysqli_prepare($link,$sql)){
                mysqli_stmt_bind_param($stmt,"i",$param_id);
                $param_id=$id;
                if(mysqli_stmt_execute($stmt)){
                    $result = mysqli_stmt_get_result($stmt);
                    if(mysqli_num_rows($result)==1){
                        $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
                        
                        $order_id = $row["order_id"];
                        $product_id = $row["product_id"];
                        $price = $row["price"];
                        $quantity = $row["quantity"];
                        $created_time = $row["created_time"];
                        $last_updated = $row["last_updated"];
                       
                    }
                    else
                    {
                        header("location:error.php");
                        exit();
                    }
                }else{
                    echo "Oops! Something went wrong. Please try again later.";
                }
            }
            mysqli_stmt_close($stmt);
            mysqli_close($link);
        }
        else{
            header("location:error.php");
            exit();
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <title>Document</title>
    <style>
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Update Record</h2>          
                    </div>
                    <p>Please edit the input values and to update the record.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        
                        <div class="form-group <?php echo(!empty($order_id_err)) ? 'has-error' : ''; ?>">
                            <label>order_id</label>
                            <input type="text" name="order_id" class="form-control" value="<?php echo $order_id; ?>">
                            <span class="help-block"><?php echo $order_id_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($product_id_err)) ? 'has-error' : ''; ?>">
                            <label>product_id</label>
                            <input type="text" name="product_id" class="form-control" value="<?php echo $product_id; ?>">
                            <span class="help-block"><?php echo $product_id_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($price_err)) ? 'has-error' : ''; ?>">
                            <label>price</label>
                            <input type="number" name="price" class="form-control" value="<?php echo $price; ?>">
                            <span class="help-block"><?php echo $price_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($quantity_err)) ? 'has-error' : ''; ?>">
                            <label>quantity</label>
                            <input type="number" name="quantity" class="form-control" value="<?php echo $quantity; ?>">
                            <span class="help-block"><?php echo $quantity_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($created_time_err)) ? 'has-error' : ''; ?>">
                            <label>created_time</label>
                            <input type="text" name="created_time" class="form-control" value="<?php echo $created_time; ?>">
                            <span class="help-block"><?php echo $created_time_err ;?></span>
                        </div>
                        <div class="form-group <?php echo(!empty($last_updated_err)) ? 'has-error' : ''; ?>">
                            <label>last_updated</label>
                            <input type="text" name="last_updated" class="form-control" value="<?php echo $last_updated; ?>">
                            <span class="help-block"><?php echo $last_updated_err ;?></span>
                        </div>
                        
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="indexmn5.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>