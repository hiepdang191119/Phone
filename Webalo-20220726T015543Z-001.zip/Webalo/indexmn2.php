<?php
include 'header.php';
// if (!empty($_SESSION['current_user'])) {
    
    if(!empty($_GET['action']) && $_GET['action'] == 'search' && !empty($_POST)){
        
        $_SESSION['product_filter']= $_POST;
        
    }
    if(!empty($_SESSION['product_filter'])){
       
        $where = "";
        foreach ($_SESSION['product_filter'] as $field => $value) {
            
            if(!empty($value)){
                switch ($field) {
                    case 'TenHangSx':
                    $where .= (!empty($where))? " AND "."`".$field."` LIKE '%".$value."%'" : "`".$field."` LIKE '%".$value."%'";
                    break;
                    default:
                    $where .= (!empty($where))? " AND "."`".$field."` = ".$value."": "`".$field."` = ".$value."";
                    break;
                }
            }
            
        }
        
        extract($_SESSION['product_filter']);
       
    }
    $item_per_page = (!empty($_GET['per_page'])) ? $_GET['per_page'] : 5;
    $current_page = (!empty($_GET['page'])) ? $_GET['page'] : 1;
    $offset = ($current_page - 1) * $item_per_page;
    if(!empty($where)){
        $totalRecords = mysqli_query($link, "SELECT * FROM tbhangsanxuat where (".$where.")");
    }else{
        $totalRecords = mysqli_query($link, "SELECT * FROM tbhangsanxuat");
    }
    $totalRecords = $totalRecords->num_rows;
    $totalPages = ceil($totalRecords / $item_per_page);
    if(!empty($where)){
        $products = mysqli_query($link, "SELECT * FROM tbhangsanxuat where (".$where.") ORDER BY MaHangSx DESC LIMIT " . $item_per_page . " OFFSET " . $offset);
        
    }else{
        $products = mysqli_query($link, "SELECT * FROM tbhangsanxuat ORDER BY MaHangSx DESC LIMIT " . $item_per_page . " OFFSET " . $offset);
    }

    mysqli_close($link);
    ?>
    <div class="main-content" style="width:600px">
        <h1>Danh sách hãng sản xuất</h1>
        <div class="product-items">
            <div class="buttons">
                <a href="create2.php">Thêm hãng sản xuất</a>
            </div>
            
            <div class="product-search">
                    <form action="indexmn2.php?action=search" method="POST">
                        <fieldset>
                            <legend>Tìm kiếm hãng sản xuất:</legend>
                            ID: <input type="text" name="MaHangSx" value="<?=!empty($MaHangSx)?$MaHangSx:""?>"/>
                            Tên hãng sản xuất: <input type="text" name="TenHangSx" value="<?=!empty($TenHangSx)?$TenHangSx:""?>"/>
                            <input type="submit" value="Tìm"/>
                        </fieldset>
                    </form>
            </div>
            <div class="total-items">
                <span>Có tất cả <strong><?=$totalRecords?></strong> hãng sản xuất trên <strong><?=$totalPages?></strong> trang</span>
            </div>
            <ul>
                <li class="product-item-heading">
                    <div class="product-prop product-id" style="width:120px">ID</div>
                    
                    <div class="product-prop product-name" style="width:201px">Tên hãng sản xuất</div>
 
                    <div class="product-prop product-button">
                        Xóa
                    </div>
                    <div class="product-prop product-button">
                        Sửa
                    </div>
                    <div class="product-prop product-button">
                        Xem
                    </div>
                    
                    <div class="clear-both"></div>
                </li>
                <?php
                while ($row = mysqli_fetch_array($products)) {
                    ?>
                    <li>
                        <div class="product-prop product-id" style="width:120px"><?= $row['MaHangSx'] ?></div>
                        <div class="product-prop product-name" style="width:201px"><?= $row['TenHangSx'] ?></div>

                        <div class="product-prop product-button">
                            <a href="delete2.php?id=<?= $row['MaHangSx'] ?>">Xóa</a>
                        </div>
                        <div class="product-prop product-button">
                            <a href="update2.php?id=<?= $row['MaHangSx'] ?>">Sửa</a>
                        </div>
                        <div class="product-prop product-button">
                            <a href="read2.php?id=<?= $row['MaHangSx'] ?>">Xem</a>
                        </div>
                        
                        <div class="clear-both"></div>
                    </li>
                <?php } ?>
            </ul>
            <?php
            include './pagination.php';
            ?>
            <div class="clear-both"></div>
        </div>
    </div>
    <?php
// }
include './footer.php';
?>